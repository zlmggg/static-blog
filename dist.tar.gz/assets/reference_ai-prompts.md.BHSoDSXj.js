import{_ as s,c as n,a2 as p,o as e}from"./chunks/framework.DBnn3rf2.js";const g=JSON.parse('{"title":"运维 AI Prompt 与 Agent 指令模板速查","description":"","frontmatter":{},"headers":[],"relativePath":"reference/ai-prompts.md","filePath":"reference/ai-prompts.md","lastUpdated":1790864665000}'),t={name:"reference/ai-prompts.md"};function l(i,a,o,c,r,d){return e(),n("div",null,[...a[0]||(a[0]=[p(`<h1 id="运维-ai-prompt-与-agent-指令模板速查" tabindex="-1">运维 AI Prompt 与 Agent 指令模板速查 <a class="header-anchor" href="#运维-ai-prompt-与-agent-指令模板速查" aria-label="Permalink to &quot;运维 AI Prompt 与 Agent 指令模板速查&quot;">​</a></h1><blockquote><p>把日常运维任务（解释命令、写脚本、诊断日志、审配置）打包成可直接复制的 Prompt 模板。 用法：复制下方代码块 → 替换占位符（<code>&lt;...&gt;</code>）→ 粘贴给任意 LLM。右侧「本页目录」可跳转。 原理与进阶见 <a href="/guide/aiops-agent-basics.html">AI Agent 基础</a>、<a href="/guide/aiops-agent-practice.html">Agent 运维实战</a>、<a href="/guide/aiops-mcp.html">MCP 协议</a>。</p></blockquote><div class="warning custom-block"><p class="custom-block-title">使用前提</p><ul><li><strong>先脱敏</strong>：把真实 IP、域名、密钥、密码、用户名、内部主机名替换成 <code>&lt;IP&gt;</code>、<code>&lt;域名&gt;</code>、<code>&lt;token&gt;</code> 再粘贴。</li><li><strong>结果需人工核对</strong>：AI 会一本正经地编造命令/版本，涉及生产的操作必须先在测试环境验证。</li><li><strong>高危操作不得直接执行</strong>：<code>rm -rf</code>、<code>DROP</code>、<code>reset --hard</code>、<code>drop</code> 库等，让 AI 先给方案与回滚步骤，人来拍板。</li></ul></div><h2 id="通用指令框架" tabindex="-1">通用指令框架 <a class="header-anchor" href="#通用指令框架" aria-label="Permalink to &quot;通用指令框架&quot;">​</a></h2><p>任何 Prompt 都按这五块组织，效果远好于&quot;帮我看看这个报错&quot;：</p><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色设定】你是一名有 10 年经验的 Linux SRE / 运维专家，熟悉 &lt;发行版/技术栈&gt;。</span></span>
<span class="line"><span>【任务目标】我希望你 &lt;具体要做的事，例如：帮我解释这条命令的每一个参数 / 诊断下面这段报错&gt;。</span></span>
<span class="line"><span>【背景上下文】系统是 &lt;Rocky 9 / K8s 1.35 / MySQL 8.0&gt;，我已经做了 &lt;尝试过的操作&gt;，现象是 &lt;现象&gt;。</span></span>
<span class="line"><span>【约束条件】不要使用晦涩术语，面向初级运维讲解；给出可直接复制的命令；如涉及生产高危操作要先提示风险并给出回滚方案。</span></span>
<span class="line"><span>【期望输出格式】用 &lt;表格 / 分步骤编号 / 代码块&gt; 输出，最后用 3 条要点总结。</span></span></code></pre></div><h2 id="_1-解释一条命令-一段配置" tabindex="-1">1. 解释一条命令 / 一段配置 <a class="header-anchor" href="#_1-解释一条命令-一段配置" aria-label="Permalink to &quot;1. 解释一条命令 / 一段配置&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是资深 Linux 运维，擅长把命令讲给新手听。</span></span>
<span class="line"><span>【任务】请逐条解释下面这条命令每个部分的含义，并说明它在什么场景下用、有什么风险：</span></span>
<span class="line"><span></span></span>
<span class="line"><span>&lt;在这里贴命令，例如：find /var/log -name &quot;*.log&quot; -mtime +7 -delete&gt;</span></span>
<span class="line"><span></span></span>
<span class="line"><span>【输出】先给一句大白话总结，再用表格拆分每段，最后列 2 个使用注意事项。</span></span></code></pre></div><p>适用：拿到一条看不懂的一行流命令，搞清楚它到底干了什么再执行。</p><h2 id="_2-解释一段配置-nginx-bind-mysql" tabindex="-1">2. 解释一段配置（Nginx / BIND / MySQL） <a class="header-anchor" href="#_2-解释一段配置-nginx-bind-mysql" aria-label="Permalink to &quot;2. 解释一段配置（Nginx / BIND / MySQL）&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是 Web/数据库运维专家。</span></span>
<span class="line"><span>【任务】下面是我的 &lt;Nginx/MySQL/BIND&gt; 配置，请逐段解释作用，并指出可能存在的安全或性能问题：</span></span>
<span class="line"><span></span></span>
<span class="line"><span>&lt;粘贴配置&gt;</span></span>
<span class="line"><span></span></span>
<span class="line"><span>【约束】用小白能懂的类比解释关键配置；发现问题按&quot;严重/一般/建议&quot;分级；不要改动我的配置逻辑，只给诊断和可选优化建议。</span></span></code></pre></div><h2 id="_3-生成-shell-python-脚本" tabindex="-1">3. 生成 Shell / Python 脚本 <a class="header-anchor" href="#_3-生成-shell-python-脚本" aria-label="Permalink to &quot;3. 生成 Shell / Python 脚本&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是 Python/Shell 自动化工程师，写过大量生产运维脚本。</span></span>
<span class="line"><span>【任务】帮我写一个 &lt;功能，例如：监控磁盘使用率超过 80% 就发企业微信告警的脚本&gt;。</span></span>
<span class="line"><span>【背景】系统 &lt;Rocky 9&gt;，已有 &lt;curl 告警接口&gt;，要检查的挂载点 &lt;data&gt;。</span></span>
<span class="line"><span>【要求】</span></span>
<span class="line"><span>1. 用 bash 或 Python3，给出完整可运行代码块；</span></span>
<span class="line"><span>2. 加详细中文注释；</span></span>
<span class="line"><span>3. 包含错误处理、日志、退出码；</span></span>
<span class="line"><span>4. 说明如何加入 crontab；</span></span>
<span class="line"><span>5. 先给我测试环境验证方法，再给上线注意事项。</span></span></code></pre></div><p>适用：重复劳动脚本化。注意让 AI 给出验证方法，不要直接上线。</p><h2 id="_4-报错日志诊断-贴日志" tabindex="-1">4. 报错日志诊断（贴日志） <a class="header-anchor" href="#_4-报错日志诊断-贴日志" aria-label="Permalink to &quot;4. 报错日志诊断（贴日志）&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是排查过千万级日志的 SRE 专家。</span></span>
<span class="line"><span>【任务】下面是我的 &lt;服务名&gt; 报错日志，请帮我定位根本原因，并给出排查步骤和修复命令。</span></span>
<span class="line"><span></span></span>
<span class="line"><span>==== 日志开始 ====</span></span>
<span class="line"><span>&lt;在这里粘贴完整报错堆栈 / 日志，已脱敏&gt;</span></span>
<span class="line"><span>==== 日志结束 ====</span></span>
<span class="line"><span></span></span>
<span class="line"><span>【背景】我已经确认 &lt;已排除的可能，例如：磁盘没满、网络通&gt;；最近变更 &lt;变更内容或&quot;无变更&quot;&gt;。</span></span>
<span class="line"><span>【输出】</span></span>
<span class="line"><span>1. 用一句话说最可能的根因；</span></span>
<span class="line"><span>2. 按可能性从高到低列出 3 个候选原因，每个配一条验证命令；</span></span>
<span class="line"><span>3. 给出修复命令（标注哪些是只读排查、哪些是变更操作）；</span></span>
<span class="line"><span>4. 给回滚方案。</span></span></code></pre></div><p>适用：贴 Java Stack Trace、MySQL 报错、Nginx 502、BIND 启动失败。注意日志长时一次贴全，别只贴最后两行。</p><h2 id="_5-告警分析" tabindex="-1">5. 告警分析 <a class="header-anchor" href="#_5-告警分析" aria-label="Permalink to &quot;5. 告警分析&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是值班 SRE。</span></span>
<span class="line"><span>【任务】这是一条告警：&lt;告警名称、触发时间、当前值、阈值&gt;。</span></span>
<span class="line"><span>【背景】相关服务 &lt;服务名&gt;，依赖 &lt;数据库/下游服务&gt;。</span></span>
<span class="line"><span>【要求】</span></span>
<span class="line"><span>1. 判断这是不是真故障，先给&quot;最可能的 3 个原因&quot;；</span></span>
<span class="line"><span>2. 列出按顺序的排查命令（从最容易验证的开始）；</span></span>
<span class="line"><span>3. 给出临时缓解措施和根治方向；</span></span>
<span class="line"><span>4. 如果是误报，给出怎么调告警阈值。</span></span></code></pre></div><p>适用：凌晨告警起来懒得想，先让 AI 给排查路径兜底。</p><h2 id="_6-系统性能分析-贴-top-iostat-输出" tabindex="-1">6. 系统性能分析（贴 top / iostat 输出） <a class="header-anchor" href="#_6-系统性能分析-贴-top-iostat-输出" aria-label="Permalink to &quot;6. 系统性能分析（贴 top / iostat 输出）&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是性能优化专家，熟悉 Linux 性能三角（CPU/内存/磁盘IO/网络）。</span></span>
<span class="line"><span>【任务】下面是我在一台变慢的机器上采集的 &lt;top / iostat -x / vmstat / ss -s&gt; 输出，请分析瓶颈在哪：</span></span>
<span class="line"><span></span></span>
<span class="line"><span>&lt;粘贴 top 或 iostat 输出&gt;</span></span>
<span class="line"><span></span></span>
<span class="line"><span>【要求】</span></span>
<span class="line"><span>1. 指出最可疑的瓶颈（CPU 高 / 内存耗尽 / IO 等待 / 网络）并给数据依据；</span></span>
<span class="line"><span>2. 给出下一步定位命令（如 pidstat、perf、dstat）；</span></span>
<span class="line"><span>3. 给临时处理建议和长期优化方向；</span></span>
<span class="line"><span>4. 不要臆测，说清楚哪个数字支持你的结论。</span></span></code></pre></div><p>适用：机器突然变慢。多贴几组间隔采样的输出，结论更准。</p><h2 id="_7-配置-代码安全审查" tabindex="-1">7. 配置 / 代码安全审查 <a class="header-anchor" href="#_7-配置-代码安全审查" aria-label="Permalink to &quot;7. 配置 / 代码安全审查&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是安全运维 / DevSecOps 工程师。</span></span>
<span class="line"><span>【任务】请审查下面的 &lt;Nginx 配置 / Shell 脚本 / K8s YAML&gt;，找出安全与规范问题：</span></span>
<span class="line"><span></span></span>
<span class="line"><span>&lt;粘贴内容&gt;</span></span>
<span class="line"><span></span></span>
<span class="line"><span>【要求】按&quot;高危/中危/低危&quot;分级列出问题，每条说明风险、修复方法和可直接替换的代码；重点检查：权限过大、明文密钥、未校验输入、暴露管理端口、缺少超时/限流。</span></span></code></pre></div><h2 id="_8-生成-runbook-应急预案" tabindex="-1">8. 生成 Runbook / 应急预案 <a class="header-anchor" href="#_8-生成-runbook-应急预案" aria-label="Permalink to &quot;8. 生成 Runbook / 应急预案&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是做过多次故障复盘的 SRE 负责人。</span></span>
<span class="line"><span>【任务】为 &lt;服务名 / 故障场景，例如：MySQL 主库宕机&gt; 写一份值班 Runbook。</span></span>
<span class="line"><span>【要求】包含：</span></span>
<span class="line"><span>1. 故障确认与分级；</span></span>
<span class="line"><span>2. 按时间线的处置步骤（每步给命令和预期结果）；</span></span>
<span class="line"><span>3. 升级路径与通知对象（写成占位符）；</span></span>
<span class="line"><span>4. 回退方案；</span></span>
<span class="line"><span>5. 复盘要收集的数据清单。</span></span>
<span class="line"><span>用编号步骤输出，命令用代码块。</span></span></code></pre></div><p>适用：把口头经验沉淀成团队可执行的应急预案。</p><h2 id="_9-sql-与正则" tabindex="-1">9. SQL 与正则 <a class="header-anchor" href="#_9-sql-与正则" aria-label="Permalink to &quot;9. SQL 与正则&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【任务】</span></span>
<span class="line"><span>1. 写一条 &lt;MySQL&gt; 查询：&lt;需求，例如：统计最近 7 天每天的订单量并按数量倒序&gt;，表结构为 &lt;粘贴建表语句&gt;。</span></span>
<span class="line"><span>2. 帮我写一个正则：&lt;需求，例如：从 Nginx 日志里提取状态码和响应时间&gt;，日志样例：&lt;贴一行真实日志&gt;。</span></span>
<span class="line"><span>【要求】先解释思路，再给可直接运行的 SQL / 正则，并给一个验证用的小例子。</span></span></code></pre></div><h2 id="_10-把概念讲给小白听" tabindex="-1">10. 把概念讲给小白听 <a class="header-anchor" href="#_10-把概念讲给小白听" aria-label="Permalink to &quot;10. 把概念讲给小白听&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是擅长类比的运维讲师。</span></span>
<span class="line"><span>【任务】请给一个刚入行、只会装系统的新手，讲清楚 &lt;概念，例如：什么是 Linux 的 inode / 什么是 K8s 的 Service / 什么是 eBPF&gt;。</span></span>
<span class="line"><span>【要求】</span></span>
<span class="line"><span>1. 先给一个生活化的类比（不要用技术名词解释技术名词）；</span></span>
<span class="line"><span>2. 再讲它解决了什么问题；</span></span>
<span class="line"><span>3. 给一个最小可操作的例子命令；</span></span>
<span class="line"><span>4. 控制在 300 字以内，避免堆砌术语。</span></span></code></pre></div><p>适用：自己学新概念时让 AI 降维解释，建立直觉后再看官方文档。</p><h2 id="_11-变更方案评审" tabindex="-1">11. 变更方案评审 <a class="header-anchor" href="#_11-变更方案评审" aria-label="Permalink to &quot;11. 变更方案评审&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>【角色】你是变更评审委员会的资深 SRE，习惯挑毛病。</span></span>
<span class="line"><span>【任务】我计划在生产执行以下变更：&lt;描述变更，例如：把 Nginx worker_connections 从 1024 调到 65535 / 给 MySQL 加从库&gt;。</span></span>
<span class="line"><span>【背景】当前配置 &lt;现状&gt;，业务高峰 &lt;时间&gt;。</span></span>
<span class="line"><span>【要求】</span></span>
<span class="line"><span>1. 找出这个方案可能忽略的风险点（至少 5 个）；</span></span>
<span class="line"><span>2. 指出可能的副作用和回滚方式；</span></span>
<span class="line"><span>3. 建议分批/灰度发布步骤；</span></span>
<span class="line"><span>4. 列出变更前后要观察的指标。</span></span></code></pre></div><p>适用：动手前让 AI 当&quot;挑刺的同事&quot;，补齐盲区。</p><h2 id="_12-多-agent-角色分工指令-诊断-执行-复核" tabindex="-1">12. 多 Agent 角色分工指令（诊断 / 执行 / 复核） <a class="header-anchor" href="#_12-多-agent-角色分工指令-诊断-执行-复核" aria-label="Permalink to &quot;12. 多 Agent 角色分工指令（诊断 / 执行 / 复核）&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>请你同时扮演三个角色，按顺序协作处理下面这个运维故障，每个角色的输出用对应标题分隔：</span></span>
<span class="line"><span></span></span>
<span class="line"><span>【诊断官】只负责分析和给出方案，不执行。先根据下面的现象列出最可能的根因和验证命令。</span></span>
<span class="line"><span>【执行官】只在诊断官确认根因后，给出最小化的修复命令序列，每条命令标注风险等级。</span></span>
<span class="line"><span>【复核官】站在对立面审查执行官的命令：哪些可能误删数据、哪些没考虑回滚、哪些需要先备份；给出最终修正版。</span></span>
<span class="line"><span></span></span>
<span class="line"><span>故障现象：&lt;粘贴现象与日志，已脱敏&gt;</span></span></code></pre></div><p>适用：复杂故障处理。关键是让&quot;复核官&quot;独立挑刺，避免 AI 一口气给出危险命令。</p><h2 id="相关指南" tabindex="-1">相关指南 <a class="header-anchor" href="#相关指南" aria-label="Permalink to &quot;相关指南&quot;">​</a></h2><ul><li>想搞懂 Agent 是什么、怎么调：<a href="/guide/aiops-agent-basics.html">AI Agent 与 LLM 应用基础</a></li><li>把 Prompt 用在真实值班里：<a href="/guide/aiops-agent-practice.html">Agent 运维实战</a></li><li>让 Agent 连上你的工具/知识库：<a href="/guide/aiops-mcp.html">MCP 模型上下文协议</a></li><li>配套命令：<a href="/reference/git-commands.html">Git 速查</a>、<a href="/reference/cloudnative-commands.html">云原生排障速查</a>、<a href="/reference/linux-commands.html">Linux 命令速查</a></li></ul><h3 id="官方文档" tabindex="-1">官方文档 <a class="header-anchor" href="#官方文档" aria-label="Permalink to &quot;官方文档&quot;">​</a></h3><ul><li>OpenAI 提示词工程指南：<a href="https://platform.openai.com/docs/guides/prompt-engineering%EF%BC%88%E9%9C%80%E7%A7%91%E5%AD%A6%E4%B8%8A%E7%BD%91%EF%BC%89%EF%BC%9B%E5%9B%BD%E5%86%85%E5%B9%B3%E6%9B%BF%EF%BC%9Ahttps://help.aliyun.com/zh/model-studio/prompt-engineering-guide" target="_blank" rel="noreferrer">https://platform.openai.com/docs/guides/prompt-engineering（需科学上网）；国内平替：https://help.aliyun.com/zh/model-studio/prompt-engineering-guide</a></li><li>Anthropic 提示词工程（Claude）：<a href="https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview%EF%BC%88%E9%9C%80%E7%A7%91%E5%AD%A6%E4%B8%8A%E7%BD%91%EF%BC%89%EF%BC%9B%E5%9B%BD%E5%86%85%E5%B9%B3%E6%9B%BF%EF%BC%9Ahttps://help.aliyun.com/zh/model-studio/prompt-engineering-guide" target="_blank" rel="noreferrer">https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview（需科学上网）；国内平替：https://help.aliyun.com/zh/model-studio/prompt-engineering-guide</a></li><li>Model Context Protocol (MCP)：<a href="https://modelcontextprotocol.io/" target="_blank" rel="noreferrer">https://modelcontextprotocol.io/</a></li><li>LangChain 文档：<a href="https://python.langchain.com/docs/" target="_blank" rel="noreferrer">https://python.langchain.com/docs/</a></li><li>Conventional Commits（提交规范）：<a href="https://www.conventionalcommits.org/zh-hans/" target="_blank" rel="noreferrer">https://www.conventionalcommits.org/zh-hans/</a></li></ul>`,43)])])}const u=s(t,[["render",l]]);export{g as __pageData,u as default};
