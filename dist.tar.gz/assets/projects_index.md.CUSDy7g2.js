import{_ as a,c as i,a2 as n,o as t}from"./chunks/framework.DBnn3rf2.js";const c=JSON.parse('{"title":"我的项目","description":"","frontmatter":{},"headers":[],"relativePath":"projects/index.md","filePath":"projects/index.md","lastUpdated":1791559408000}'),l={name:"projects/index.md"};function e(h,s,p,d,k,r){return t(),i("div",null,[...s[0]||(s[0]=[n(`<h1 id="我的项目" tabindex="-1">我的项目 <a class="header-anchor" href="#我的项目" aria-label="Permalink to &quot;我的项目&quot;">​</a></h1><blockquote><p>这里放我<strong>真实动手做过的东西</strong>——自己搭的环境、部署的服务、踩过的坑，每一个都能讲出细节。</p><p>跟 <a href="/cases/">排障训练场</a> 的区别：训练场是我整理、在实验环境复现过的<strong>典型教学场景</strong>；这里每一个都是我亲手折腾出来的。</p></blockquote><h2 id="项目列表" tabindex="-1">项目列表 <a class="header-anchor" href="#项目列表" aria-label="Permalink to &quot;项目列表&quot;">​</a></h2><table tabindex="0"><thead><tr><th>项目</th><th>简介</th><th>技术栈</th><th>状态</th></tr></thead><tbody><tr><td><a href="./site-blog.html">禾光知寒站点</a></td><td>你正在看的这个知识库：从主题定制到部署上线</td><td>VitePress · Vue · Docker · Nginx</td><td>✅ 已上线</td></tr><tr><td><a href="./aliyun-deploy.html">阿里云个人站点部署</a></td><td>ECS 挂数据盘、Docker Compose 跑 Nginx 与监控、主机加固</td><td>阿里云 · Docker · Nginx · Netdata</td><td>✅ 已上线</td></tr><tr><td><a href="./homelab.html">家庭实验室 Homelab</a></td><td>双路 E5 + 128G ECC，部署 OpenStack / KVM 练手云平台</td><td>X99 · OpenStack · KVM/QEMU</td><td>🚧 持续折腾</td></tr></tbody></table><h2 id="真实踩坑记录" tabindex="-1">真实踩坑记录 <a class="header-anchor" href="#真实踩坑记录" aria-label="Permalink to &quot;真实踩坑记录&quot;">​</a></h2><blockquote><p>这些是在上面项目里实际遇到、当场解决的问题：</p></blockquote><ul><li><a href="/cases/t-docker-swap.html">Docker swap 限制不生效（No swap limit support）</a></li></ul><h2 id="项目文章怎么写" tabindex="-1">项目文章怎么写 <a class="header-anchor" href="#项目文章怎么写" aria-label="Permalink to &quot;项目文章怎么写&quot;">​</a></h2><details class="details custom-block"><summary>新建项目文章时，复制这个结构</summary><div class="language-markdown vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">markdown</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">---</span></span>
<span class="line"><span style="--shiki-light:#22863A;--shiki-dark:#85E89D;">category</span><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">: </span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;">项目</span></span>
<span class="line"><span style="--shiki-light:#22863A;--shiki-dark:#85E89D;">difficulty</span><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">: </span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;">中级</span></span>
<span class="line"><span style="--shiki-light:#22863A;--shiki-dark:#85E89D;">date</span><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">: </span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;">YYYY-MM-DD</span></span>
<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">---</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#005CC5;--shiki-light-font-weight:bold;--shiki-dark:#79B8FF;--shiki-dark-font-weight:bold;"># 项目名称</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#22863A;--shiki-dark:#85E89D;">&gt; 一句话说明这是什么、解决什么问题。</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#005CC5;--shiki-light-font-weight:bold;--shiki-dark:#79B8FF;--shiki-dark-font-weight:bold;">## 一、背景 / 目标</span></span>
<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">（为什么做，想达到什么效果）</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#005CC5;--shiki-light-font-weight:bold;--shiki-dark:#79B8FF;--shiki-dark-font-weight:bold;">## 二、架构 / 环境</span></span>
<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">（真实的机器、版本、网络拓扑，尽量写具体）</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#005CC5;--shiki-light-font-weight:bold;--shiki-dark:#79B8FF;--shiki-dark-font-weight:bold;">## 三、关键步骤</span></span>
<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">（分步骤，配可复制的命令 / 配置）</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#005CC5;--shiki-light-font-weight:bold;--shiki-dark:#79B8FF;--shiki-dark-font-weight:bold;">## 四、踩过的坑 &amp; 解决</span></span>
<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">（现象 → 原因 → 怎么解决的）</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#005CC5;--shiki-light-font-weight:bold;--shiki-dark:#79B8FF;--shiki-dark-font-weight:bold;">## 五、成果 / 复盘</span></span>
<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">（做成了什么、学到什么、下次怎么更好）</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#005CC5;--shiki-light-font-weight:bold;--shiki-dark:#79B8FF;--shiki-dark-font-weight:bold;">## 六、相关链接</span></span>
<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">（代码仓库、相关速查 / 文章）</span></span></code></pre></div></details>`,9)])])}const g=a(l,[["render",e]]);export{c as __pageData,g as default};
