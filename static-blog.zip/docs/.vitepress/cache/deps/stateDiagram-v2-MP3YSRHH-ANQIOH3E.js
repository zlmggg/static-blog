import {
  StateDB,
  stateDiagram_default,
  stateRenderer_v3_unified_default,
  styles_default
} from "./chunk-4B7C6QHU.js";
import "./chunk-FGTMAWFZ.js";
import "./chunk-H55NGVLP.js";
import "./chunk-US5RQOKV.js";
import "./chunk-64WMPS3H.js";
import "./chunk-E3UJLROV.js";
import "./chunk-CNKKPMJA.js";
import "./chunk-EN5MJLIN.js";
import "./chunk-FFR52JZC.js";
import "./chunk-MEDWME2N.js";
import "./chunk-WGPVAJBU.js";
import "./chunk-T6IDJC4I.js";
import "./chunk-P46J6XIC.js";
import "./chunk-7H6KKAY2.js";
import "./chunk-KEATWLHG.js";
import "./chunk-IKQMEQWV.js";
import "./chunk-UKYU44FA.js";
import {
  __name
} from "./chunk-DTCXZATX.js";
import "./chunk-EQCVQC35.js";

// node_modules/mermaid/dist/chunks/mermaid.core/stateDiagram-v2-MP3YSRHH.mjs
var diagram = {
  parser: stateDiagram_default,
  get db() {
    return new StateDB(2);
  },
  renderer: stateRenderer_v3_unified_default,
  styles: styles_default,
  init: __name((cnf) => {
    if (!cnf.state) {
      cnf.state = {};
    }
    cnf.state.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};
export {
  diagram
};
//# sourceMappingURL=stateDiagram-v2-MP3YSRHH-ANQIOH3E.js.map
