import {
  createFlowDiagram,
  styles_default
} from "./chunk-5Y54RCQW.js";
import "./chunk-4TNKLG3H.js";
import "./chunk-FGTMAWFZ.js";
import "./chunk-H55NGVLP.js";
import "./chunk-US5RQOKV.js";
import "./chunk-6WH7T6QG.js";
import "./chunk-64WMPS3H.js";
import "./chunk-E3UJLROV.js";
import "./chunk-CNKKPMJA.js";
import "./chunk-EN5MJLIN.js";
import "./chunk-FFR52JZC.js";
import "./chunk-MEDWME2N.js";
import "./chunk-WGPVAJBU.js";
import "./chunk-T6IDJC4I.js";
import "./chunk-P46J6XIC.js";
import "./chunk-7H6KKAY2.js";
import "./chunk-KEATWLHG.js";
import "./chunk-IKQMEQWV.js";
import "./chunk-UKYU44FA.js";
import {
  __name
} from "./chunk-DTCXZATX.js";
import "./chunk-EQCVQC35.js";

// node_modules/mermaid/dist/chunks/mermaid.core/swimlanesDiagram-VR7AAH4N.mjs
var getStyles = __name((options) => `${styles_default(options)}
  .swimlane.cluster rect {
    stroke: ${options.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`, "getStyles");
var styles_default2 = getStyles;
var diagram = createFlowDiagram({ defaultLayout: "swimlane", styles: styles_default2 });
export {
  diagram
};
//# sourceMappingURL=swimlanesDiagram-VR7AAH4N-ZUXIRQLT.js.map
